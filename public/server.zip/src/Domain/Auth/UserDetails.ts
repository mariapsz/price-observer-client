export interface UserDetails {
    userId: number;
    email: string;
    userName: string;
    userRolesArray: string[];
}
